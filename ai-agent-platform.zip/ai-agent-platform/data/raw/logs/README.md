This directory is intended for log files. Add log files here.
