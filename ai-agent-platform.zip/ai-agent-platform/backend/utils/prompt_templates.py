"""
prompt_templates.py

Define custom prompt templates for interacting with LlamaIndex and guiding responses.
"""
# Define prompt templates or functions here

DEFAULT_PROMPT = """
You are an AI assistant that provides information about the system. Please ask a specific question.
"""
