# Adventure in the Whispering Woods: an interactive story

This *choose‑your‑own* adventure story lets you become part of an epic journey in a fantasy world.  
At the end of each section you will face a **choice**.  
Your decision will direct you to another numbered section in this document, so pay attention to the options given.  

## 1. Theme
The story is set in a **fantasy world** filled with mysterious forests, magical creatures and ancient secrets.  
You will explore dark woods, visit enchanted villages and encounter mythical beings as you guide your chosen characters.

## 2. Characters
Choose a hero (or play as all of them) and imagine their personality influencing the decisions they make:

- **Aria** – a young herbalist with an innate sense of magic.  
  She grew up in a small village and longs for adventure. Aria is empathetic and curious, but her lack of experience sometimes leads her into trouble.
- **Finn** – a sturdy dwarf warrior from the northern mines.  
  Loyal and brave, Finn values honour and strength. He carries a heavy axe and is protective of his friends, though he can be stubborn.
- **Nyx** – an enigmatic wanderer who can meld into the shadows.  
  Nyx’s past is shrouded in mystery; they rarely speak of where they came from. Practical and resourceful, Nyx has a sharp mind and a cautious nature.

*(You can pick one character to focus on, or treat all three as companions traveling together.)*

## 3. Beginning the story
It is the eve of the summer festival in **Eldoria**, a peaceful town on the edge of the **Whispering Woods**. As villagers dance and sing, the mayor calls you aside.  

> “Brave adventurers,” she whispers, “something sinister lurks in the woods.  
> A shadowy presence has been taking villagers who wander too far. We need someone to investigate and put an end to it.”  

Aria’s eyes gleam with determination, Finn grips his axe and nods, and Nyx melts deeper into the shadows, listening.  

### What do you do?

1. **Prepare for the journey immediately** — head to the woods at dawn, eager to face whatever awaits. (Go to **Section 4**)
2. **Gather information first** — visit the local tavern to ask elders and travellers if they have noticed anything unusual. (Go to **Section 5**)

## 4. Into the woods
You set out at dawn. Mist clings to the ground and the Whispering Woods seem to breathe with ancient life. Birds fall silent as you cross the threshold.  

After walking for an hour you reach a fork in the path. To the **left**, a narrow trail winds down toward a sparkling river whose waters emit an eerie blue glow. To the **right**, a faint path climbs toward the ruins of an old tower half‑hidden by thick vines.  

### Which path do you choose?

1. **Follow the glowing river**. (Go to **Section 6**)
2. **Climb toward the vine‑covered tower**. (Go to **Section 7**)

## 5. Gathering knowledge
You enter the tavern just as dawn paints the sky pink. The barkeep eyes you curiously and pours a mug of ale. A group of old hunters sit in a corner, whispering about their experiences. An ancient storyteller by the fire smiles as you approach.  

You may choose whom to talk to for information:

1. **The old hunters** – they have survived many nights in the woods and might know of recent dangers. (Go to **Section 8**)
2. **The storyteller** – their tales often contain hidden truths about the Whispering Woods’ history. (Go to **Section 9**)

## 6. Along the glowing river
The river hums with arcane energy and glows softly. As you follow its course, you spot unusual footprints at the edge of the water. Suddenly the surface breaks and a **water sprite** emerges, her translucent skin shimmering.  

> “Why do mortals disturb my stream?” she asks. “If you seek the darkness beyond, you must answer my riddle.”  

She offers a challenge: *“I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I?”*

### How do you respond?

1. **Answer the riddle** — if you know the solution, speak it. (If you answer “**an echo**”, the sprite will smile and let you pass; otherwise she will banish you back to the fork.)
2. **Attack the sprite** — Finn raises his axe, ready to fight. (Go to **Section 10**)
3. **Attempt to reason** — Aria tries to persuade the sprite to let you pass without answering. (Go to **Section 11**)

*(If you answered correctly, go to **Section 12**.)*

## 7. The vine‑covered tower
As you climb the hill, ancient stones loom through the mist. The tower appears abandoned, but as you approach, vines writhe like snakes. A chill runs down your spine.  

The entrance is blocked by a heavy wooden door covered in glowing sigils. Nyx inspects the markings — they appear to be protective runes.  

### What do you do?

1. **Attempt to decipher the runes** — Aria’s knowledge of herbs might help interpret the symbols. (Go to **Section 13**)
2. **Use brute force** — Finn tries to break the door down. (Go to **Section 14**)
3. **Find another way in** — Nyx looks for a hidden passage or window. (Go to **Section 15**)

## 8. The hunters’ whispers
The hunters share fearful glances. “We’ve seen **shadow wolves** in the woods,” one mutters. “Black as night, eyes like burning coals. They came from the direction of the old tower on the hill.”  

Another adds, “There’s talk of a sorcerer returning to reclaim the tower. He was banished years ago for experimenting with dark magic.”  

Armed with this new knowledge, you realise the danger may be centred on the tower rather than the deeper forest.  

### Your choice:

1. **Head straight to the tower** to confront whatever resides there. (Go to **Section 7**)
2. **Seek the sorcerer’s name** by speaking to the storyteller for more lore. (Go to **Section 9**)

## 9. The storyteller’s tale
The elderly storyteller leans forward. “Long ago, a mage named **Malgar** built a tower in the woods. He sought immortality and began stealing villagers’ spirits. A band of heroes defeated him, but legends say his essence was bound to a dark crystal hidden deep within the tower.”  

The storyteller warns, “If Malgar’s crystal falls into the wrong hands or if he gathers enough souls, he could return. Beware the tower’s traps and the creatures guarding it.”  

### Your choice:

1. **Travel to the tower** armed with this knowledge. (Go to **Section 7**)
2. **Collect more allies** in Eldoria before confronting the danger. (Go to **Section 16**)

## 10. Fighting the sprite
Finn charges at the water sprite. Her eyes flash, and she summons a wave that knocks him back. Aria and Nyx struggle against the torrent. Realising the sprite is too powerful in her domain, you retreat to the fork, soaked and chastened.  

*(Return to **Section 4** and choose again, or abandon the river path.)*

## 11. Reasoning with the sprite
Aria steps forward, hands raised. “We mean no harm,” she says. “We only wish to stop the shadow corrupting the woods.”  

The sprite’s gaze softens. “Very well,” she replies. “I will let you pass if you carry this vial of pure water. Use it to weaken darkness when you find its source.”  

You accept the vial. Grateful, you continue along the river until it leads you to the entrance of the vine‑covered tower from **Section 7**.  

*(Proceed to **Section 7** and add a **vial of pure water** to your inventory. It may help later.)*

## 12. Passing the riddle
You answer, “An echo.” The sprite smiles. “Clever mortal. You may proceed.” She hands you a **shimmering scale** as a token of gratitude.  

As you continue along the river, you hear howls in the distance. Suddenly a pack of **shadow wolves** emerges, blocking your path. Their eyes burn and shadows drip from their fur.  

### What do you do?

1. **Fight the wolves** — Finn readies his axe and charges. (Go to **Section 17**)
2. **Use the shimmering scale** — perhaps it has protective properties. (Go to **Section 18**)
3. **Flee back toward the tower**. (Go to **Section 7**)

## 13. Deciphering the runes
Aria studies the glowing sigils and recognises them as a ward against dark magic. With careful tracing and a whispered incantation, she deactivates the runes. The door swings open with a groan.  

Inside, a spiral staircase descends into the tower’s depths.  

### Do you:

1. **Descend immediately**, trusting your courage. (Go to **Section 19**)
2. **Search the ground floor** for clues before heading down. (Go to **Section 20**)

## 14. Using brute force
Finn slams his shoulder against the door, but the magical wards hurl him backwards. He tumbles down the hill, bruised and winded. The runes glow brighter, making it clear that force won’t work.  

*(Return to **Section 7** and choose another option.)*

## 15. Seeking a hidden entrance
Nyx circles the tower and finds a small, concealed window covered by vines. Sliding silently through, they find themselves in a room filled with dusty tomes and an old **lab journal** left by Malgar.  

Nyx grabs the journal and slips back out. You now have knowledge of the sorcerer’s experiments, which may reveal his weaknesses.  

*(Return to **Section 7**, then proceed to **Section 13** or take another action. The **lab journal** can help in Sections 19 and 21.)*

## 16. Gathering allies
You decide not to face the darkness alone. Over the next few days you recruit **two brave villagers**, a **cleric** who can heal and a **blacksmith** skilled in making weapons. With a larger group, you feel more confident.  

However, the longer you delay, the more villagers disappear into the woods. When you finally reach the tower, you discover that Malgar’s strength has grown. The final confrontation will be harder.  

*(Proceed to **Section 7**, but note that enemies in Sections 19 and 21 will be stronger.)*

## 17. Battle with the shadow wolves
Finn swings his axe, and the battle begins. The wolves are swift, but the shimmering scale glows, protecting your group. After a fierce fight you defeat the pack, though Finn sustains injuries. You proceed toward the tower, weary but undeterred.  

*(Gain **combat experience**. Proceed to **Section 7**.)*

## 18. Using the shimmering scale
You hold the scale high, and a bright light emanates from it. The wolves recoil, whimpering as the light burns away the darkness clinging to them.  

As the shadows dissipate, the wolves transform into normal forest wolves and scamper off, freed from Malgar’s control. Grateful, you continue toward the tower.  

*(Gain **blessing of the river sprite**. Proceed to **Section 7**.)*

## 19. Descending into darkness
The staircase creaks as you descend. The air grows cold and damp. At the bottom you find a cavernous chamber illuminated by a floating **dark crystal** pulsing with sinister energy. Bound souls swirl inside. Malgar’s essence begins to coalesce around it.  

### What do you do?

1. **Smash the crystal** with brute force. (Go to **Section 21**)
2. **Use the vial of pure water** from Section 11 to purify it. (Go to **Section 22**)
3. **Recite a banishing spell** from the lab journal obtained in Section 15. (Go to **Section 23**)

## 20. Searching the ground floor
You find shelves of books, alchemical equipment and a chest containing **healing herbs** and an **iron key**. These may come in handy later.  

After collecting the items, you join your companions at the stairway and descend.  

*(Add **healing herbs** and an **iron key** to your inventory. Proceed to **Section 19**.)*

## 21. Shattering the crystal
Finn raises his axe and brings it down on the dark crystal. It cracks, releasing a shockwave of energy. Malgar screams as his essence is dragged back into the void, but the blast knocks you all off your feet.  

Without the proper ritual, the souls inside are lost, and the cavern begins to collapse. You manage to escape, but the villagers’ spirits are gone forever. Eldoria is safe, but at great cost.  

### Ending 1 – Bittersweet victory
The town celebrates your success, but you are haunted by the loss of the captured souls. Perhaps there was another way…

## 22. Purifying the crystal
You uncork the vial of pure water and pour it over the crystal. Light spreads across its surface, and the swirling souls begin to calm. Malgar’s essence shrieks as it is purified. The crystal melts into a puddle of clear water, and the spirits are released.  

### Ending 2 – Peaceful resolution
The freed souls drift upward, whispering thanks. Eldoria rejoices not only for its safety but also for the return of their loved ones. Your names will be spoken with reverence for generations.

## 23. Banishing spell
You open Malgar’s lab journal and find a spell designed to bind his spirit forever. You and your companions chant the incantation. The crystal glows; tendrils of dark energy lash out, but the iron key from Section 20 fits into a hidden lock at the crystal’s base.  

As you turn the key, the spell completes. Malgar’s essence is sucked into the journal, which seals shut. The crystal turns to dust, and the captured souls are released unharmed.  

### Ending 3 – Clever triumph
By using the knowledge you gathered, you not only defeat Malgar but also save every soul. Eldoria honours you as heroes of wisdom and courage.

---

## 9. Showcase and share your story
To share your adventure, you can recount the path you chose or challenge others to explore different branches. Discuss your decisions and how they shaped the outcome. Perhaps new heroes will find other secrets hidden within the Whispering Woods…

*This interactive story was designed following the guidelines from the course project description that emphasise defining a theme, creating characters, building a narrative, prompting user choices, providing AI‑generated responses and offering multiple conclusions.*
